export const environment = {
    production: false,
    endpoint: 'http://localhost:3001/'
  };