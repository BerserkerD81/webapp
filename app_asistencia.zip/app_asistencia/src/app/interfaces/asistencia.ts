export interface asistencia {
    curso_nombre: string,
    fecha: string
    hora_inicio: string 
    hora_fin:string
    dia:string
    estado: string
    motivo: string
    profesor_rut:string
    seccion:string
}