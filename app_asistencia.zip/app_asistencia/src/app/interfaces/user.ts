export interface User {
    rut: string,
    password: string
    nombre:string
    rol:string,
    estado:string,
    email:string
}