import { Component } from '@angular/core';

@Component({
  selector: 'app-my-header',
  standalone: true,
  templateUrl: './my-header.component.html',
  styleUrls: ['./my-header.component.css']
})
export class MyHeaderComponent {

}
