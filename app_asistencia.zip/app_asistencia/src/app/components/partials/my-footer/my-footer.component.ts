import { Component } from '@angular/core';

@Component({
  selector: 'app-my-footer',
  standalone: true,
  imports: [],
  templateUrl: './my-footer.component.html',
  styleUrl: './my-footer.component.css'
})
export class MyFooterComponent {

}
