import { Component } from '@angular/core';

@Component({
  selector: 'app-ok-dialog',
  templateUrl: './ok-dialog.component.html',
  styleUrl: './ok-dialog.component.css'
})
export class OkDialogComponent {

}
