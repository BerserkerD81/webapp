import { AppModule } from "./app/app.module"
import { AppServerModule } from "./app/app.module.server"

export { AppServerModule as default }